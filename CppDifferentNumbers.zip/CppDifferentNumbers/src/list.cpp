#include <string.h>
#include <cassert>
#include <stdlib.h> 

#include "list.h"


List::List() {}

int List::f() {
	return 17;
}


