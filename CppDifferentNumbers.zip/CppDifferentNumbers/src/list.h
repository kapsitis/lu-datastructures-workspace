#pragma once

// List of integers
class List {
public:
	List();
	int f();
};

/*
const char* test();
char* sha256(char* arg);
int binToHex(const unsigned char* input, int len, char** hex);
*/

